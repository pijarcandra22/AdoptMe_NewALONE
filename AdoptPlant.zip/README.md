# AdoptMe_NewALONE
ini adalah project yang sepantasnya dibuat bersama tetapi berakhir aku buat sendiri huhu

Yeee sekarang ada yande wkwkw
