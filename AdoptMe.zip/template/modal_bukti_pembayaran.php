<html>
    <div class="modal fade" id="modal_bukti_pembayaran" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 700px; border-radius:10px">
            <div class="modal-content" style="box-shadow: 10px 0px 30px rgba(0, 0, 0, 0.5); border:none">
                <div class="modal-body" style="margin-top: 0;">
                    <button style="position: absolute; top:20px; right:20px" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <form role="form" enctype = "multipart/form-data">
                        <div id="report_img" style="background-size: cover; width:100%; height:600px; background-color:aquamarine"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</html>