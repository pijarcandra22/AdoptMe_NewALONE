<?php 

// 2. Cek Gaji
// 3. Konfirmasi gaji sudah diterima

?>